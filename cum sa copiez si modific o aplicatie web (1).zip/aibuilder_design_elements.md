# Elemente de design pentru o pagină de vânzare cu conversie ridicată pentru AiBuilder.biz

## 1. Header optimizat "Above the fold"

```html
<header class="hero-section">
  <div class="container">
    <div class="hero-content">
      <h1 class="main-headline">Transformă-ți expertiza într-un curs online profitabil în doar câteva zile</h1>
      <h2 class="sub-headline">AI Builder creează automat cursuri premium din cunoștințele tale, fără efort tehnic</h2>
      
      <div class="hero-cta-container">
        <a href="#pricing" class="cta-button primary">Începe să creezi acum</a>
        <p class="urgency-note">Primii 50 de utilizatori primesc acces la modulul VIP de marketing</p>
      </div>
      
      <div class="hero-video">
        <!-- Video demonstrativ de 60 secunde -->
        <div class="video-container">
          <img src="demo-video-thumbnail.jpg" alt="Vezi cum funcționează AI Builder" class="video-thumbnail">
          <div class="play-button">▶</div>
        </div>
        <p class="video-caption">Vezi cum AI Builder transformă cunoștințele în cursuri în doar 3 minute</p>
      </div>
    </div>
    
    <div class="social-proof-bar">
      <div class="users-count">
        <strong>1,500+</strong> experți folosesc AI Builder
      </div>
      <div class="rating">
        <span class="stars">★★★★★</span>
        <span class="rating-count">4.8/5 din 230 recenzii</span>
      </div>
      <div class="trusted-by">
        <span>Utilizat de experți din:</span>
        <img src="company-logos.png" alt="Companii partenere" class="partner-logos">
      </div>
    </div>
  </div>
</header>
```

### Stilizare CSS pentru header

```css
.hero-section {
  background: linear-gradient(135deg, #1a2a6c, #b21f1f, #fdbb2d);
  color: white;
  padding: 60px 0;
  text-align: center;
}

.main-headline {
  font-size: 2.8rem;
  font-weight: 800;
  margin-bottom: 20px;
  line-height: 1.2;
}

.sub-headline {
  font-size: 1.6rem;
  font-weight: 400;
  margin-bottom: 30px;
  max-width: 800px;
  margin-left: auto;
  margin-right: auto;
}

.hero-cta-container {
  margin: 30px 0;
}

.cta-button.primary {
  background-color: #FF6B00;
  color: white;
  font-size: 1.2rem;
  font-weight: 700;
  padding: 15px 40px;
  border-radius: 50px;
  text-decoration: none;
  display: inline-block;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(255, 107, 0, 0.4);
}

.cta-button.primary:hover {
  background-color: #FF8C00;
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(255, 107, 0, 0.6);
}

.urgency-note {
  font-size: 1rem;
  margin-top: 15px;
  color: #FFD700;
}

.video-container {
  position: relative;
  max-width: 700px;
  margin: 0 auto;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  cursor: pointer;
}

.video-thumbnail {
  width: 100%;
  display: block;
}

.play-button {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: rgba(255, 107, 0, 0.9);
  color: white;
  width: 70px;
  height: 70px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  transition: all 0.3s ease;
}

.video-container:hover .play-button {
  background-color: rgba(255, 140, 0, 0.9);
  transform: translate(-50%, -50%) scale(1.1);
}

.social-proof-bar {
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  padding: 15px;
  margin-top: 40px;
  display: flex;
  justify-content: space-around;
  align-items: center;
  flex-wrap: wrap;
}

.stars {
  color: #FFD700;
  letter-spacing: 2px;
}

.partner-logos {
  height: 30px;
  margin-left: 10px;
}
```

## 2. Secțiunea "Problema și Soluția"

```html
<section class="problem-solution">
  <div class="container">
    <div class="section-header">
      <h2>De ce crearea cursurilor online este atât de dificilă?</h2>
      <p class="section-subtitle">Majoritatea experților se confruntă cu aceste provocări:</p>
    </div>
    
    <div class="problems-grid">
      <div class="problem-card">
        <div class="problem-icon">⏱️</div>
        <h3>Timp excesiv</h3>
        <p>Crearea unui curs de calitate durează săptămâni sau chiar luni de muncă intensă</p>
      </div>
      
      <div class="problem-card">
        <div class="problem-icon">🔧</div>
        <h3>Complexitate tehnică</h3>
        <p>Necesită cunoștințe de design, editare video și platforme de e-learning</p>
      </div>
      
      <div class="problem-card">
        <div class="problem-icon">💰</div>
        <h3>Costuri ridicate</h3>
        <p>Angajarea specialiștilor pentru crearea de conținut premium costă mii de euro</p>
      </div>
    </div>
    
    <div class="solution-container">
      <div class="solution-header">
        <h2>Prezentăm <span class="highlight">AI Builder</span></h2>
        <p class="solution-subtitle">Creatorul automat de cursuri care transformă expertiza ta într-un program premium în câteva ore</p>
      </div>
      
      <div class="solution-image">
        <img src="solution-image.jpg" alt="AI Builder în acțiune" class="solution-screenshot">
      </div>
      
      <div class="solution-benefits">
        <div class="benefit-item">
          <div class="check-icon">✓</div>
          <p>Generează automat structura cursului din cunoștințele tale</p>
        </div>
        <div class="benefit-item">
          <div class="check-icon">✓</div>
          <p>Creează slide-uri profesionale cu design premium</p>
        </div>
        <div class="benefit-item">
          <div class="check-icon">✓</div>
          <p>Transformă ideile tale în module complete în câteva minute</p>
        </div>
        <div class="benefit-item">
          <div class="check-icon">✓</div>
          <p>Economisește săptămâni de muncă și mii de euro</p>
        </div>
      </div>
    </div>
  </div>
</section>
```

### Stilizare CSS pentru secțiunea Problema și Soluția

```css
.problem-solution {
  padding: 80px 0;
  background-color: #f8f9fa;
}

.section-header {
  text-align: center;
  margin-bottom: 50px;
}

.section-header h2 {
  font-size: 2.4rem;
  color: #333;
  margin-bottom: 15px;
}

.section-subtitle {
  font-size: 1.2rem;
  color: #666;
  max-width: 700px;
  margin: 0 auto;
}

.problems-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
  margin-bottom: 60px;
}

.problem-card {
  background-color: white;
  border-radius: 12px;
  padding: 30px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
  text-align: center;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.problem-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

.problem-icon {
  font-size: 2.5rem;
  margin-bottom: 20px;
}

.problem-card h3 {
  font-size: 1.4rem;
  margin-bottom: 15px;
  color: #333;
}

.problem-card p {
  color: #666;
  line-height: 1.6;
}

.solution-container {
  background-color: white;
  border-radius: 12px;
  padding: 40px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.solution-header {
  text-align: center;
  margin-bottom: 40px;
}

.solution-header h2 {
  font-size: 2.2rem;
  color: #333;
  margin-bottom: 15px;
}

.highlight {
  color: #FF6B00;
  font-weight: 700;
}

.solution-subtitle {
  font-size: 1.2rem;
  color: #666;
  max-width: 700px;
  margin: 0 auto;
}

.solution-image {
  text-align: center;
  margin-bottom: 40px;
}

.solution-screenshot {
  max-width: 100%;
  border-radius: 8px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.solution-benefits {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
}

.benefit-item {
  display: flex;
  align-items: flex-start;
}

.check-icon {
  color: #4CAF50;
  font-size: 1.2rem;
  font-weight: bold;
  margin-right: 10px;
  flex-shrink: 0;
}

.benefit-item p {
  margin: 0;
  color: #333;
  line-height: 1.5;
}
```

## 3. Secțiunea "Cum funcționează"

```html
<section class="how-it-works">
  <div class="container">
    <div class="section-header">
      <h2>Cum funcționează AI Builder</h2>
      <p class="section-subtitle">Trei pași simpli pentru a-ți transforma expertiza într-un curs premium</p>
    </div>
    
    <div class="steps-container">
      <div class="step-card">
        <div class="step-number">1</div>
        <div class="step-content">
          <h3>Adaugă cunoștințele tale</h3>
          <p>Introdu ideile principale, conceptele și expertiza ta în interfața intuitivă</p>
          <img src="step1-image.jpg" alt="Adăugare cunoștințe" class="step-image">
        </div>
      </div>
      
      <div class="step-connector"></div>
      
      <div class="step-card">
        <div class="step-number">2</div>
        <div class="step-content">
          <h3>AI Builder generează cursul</h3>
          <p>Algoritmul nostru transformă automat informațiile în module structurate și slide-uri profesionale</p>
          <img src="step2-image.jpg" alt="Generare automată" class="step-image">
        </div>
      </div>
      
      <div class="step-connector"></div>
      
      <div class="step-card">
        <div class="step-number">3</div>
        <div class="step-content">
          <h3>Lansează și vinde cursul tău</h3>
          <p>Exportă cursul finalizat și începe să-l vinzi imediat pe platforma ta preferată</p>
          <img src="step3-image.jpg" alt="Lansare curs" class="step-image">
        </div>
      </div>
    </div>
    
    <div class="demo-cta">
      <h3>Vezi AI Builder în acțiune</h3>
      <p>Urmărește o demonstrație completă de 5 minute</p>
      <a href="#demo-video" class="cta-button secondary">Vizionează demo</a>
    </div>
  </div>
</section>
```

### Stilizare CSS pentru secțiunea Cum funcționează

```css
.how-it-works {
  padding: 80px 0;
  background-color: white;
}

.steps-container {
  margin: 60px 0;
  position: relative;
}

.step-card {
  display: flex;
  margin-bottom: 40px;
  position: relative;
  z-index: 2;
}

.step-number {
  background-color: #FF6B00;
  color: white;
  width: 60px;
  height: 60px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.8rem;
  font-weight: bold;
  flex-shrink: 0;
  margin-right: 30px;
  box-shadow: 0 5px 15px rgba(255, 107, 0, 0.3);
}

.step-content {
  flex-grow: 1;
  background-color: #f8f9fa;
  border-radius: 12px;
  padding: 30px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
}

.step-content h3 {
  font-size: 1.4rem;
  margin-bottom: 15px;
  color: #333;
}

.step-content p {
  color: #666;
  margin-bottom: 20px;
  line-height: 1.6;
}

.step-image {
  width: 100%;
  border-radius: 8px;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
}

.step-connector {
  position: absolute;
  left: 30px;
  top: 60px;
  bottom: 60px;
  width: 2px;
  background-color: #FF6B00;
  z-index: 1;
}

.demo-cta {
  text-align: center;
  background-color: #f8f9fa;
  border-radius: 12px;
  padding: 40px;
  margin-top: 40px;
}

.demo-cta h3 {
  font-size: 1.6rem;
  margin-bottom: 15px;
  color: #333;
}

.demo-cta p {
  color: #666;
  margin-bottom: 20px;
}

.cta-button.secondary {
  background-color: #333;
  color: white;
  font-size: 1.1rem;
  font-weight: 600;
  padding: 12px 30px;
  border-radius: 50px;
  text-decoration: none;
  display: inline-block;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.cta-button.secondary:hover {
  background-color: #555;
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
}
```

## 4. Secțiunea de testimoniale și studii de caz

```html
<section class="testimonials">
  <div class="container">
    <div class="section-header">
      <h2>Ce spun experții despre AI Builder</h2>
      <p class="section-subtitle">Iată rezultatele reale obținute de utilizatorii noștri</p>
    </div>
    
    <div class="featured-case-study">
      <div class="case-study-content">
        <div class="case-study-header">
          <img src="andrei-profile.jpg" alt="Andrei, Coach Spiritual" class="profile-image">
          <div class="case-study-meta">
            <h3>Andrei, Coach Spiritual</h3>
            <div class="results-highlight">
              <span class="result-number">2,500€</span> venituri în prima lună
            </div>
          </div>
        </div>
        
        <div class="case-study-story">
          <p class="challenge">"Înainte de AI Builder, am încercat luni de zile să-mi creez cursul de dezvoltare spirituală. Era frustrant și consumator de timp."</p>
          
          <p class="solution">"Cu AI Builder, am transformat ideile mele într-un curs complet în doar două zile. Platforma a generat automat structura, slide-urile și materialele de curs."</p>
          
          <p class="results">"Am lansat cursul imediat și am generat vânzări de 2,500€ în prima lună. Mi-am recuperat investiția de 12 ori în doar câteva zile!"</p>
          
          <div class="course-preview">
            <img src="andrei-course.jpg" alt="Cursul lui Andrei" class="course-image">
          </div>
        </div>
      </div>
    </div>
    
    <div class="testimonials-grid">
      <div class="testimonial-card">
        <div class="testimonial-header">
          <img src="alex-profile.jpg" alt="Alex, Ecommerce" class="profile-image-small">
          <div class="testimonial-meta">
            <h4>Alex, Expert Ecommerce</h4>
            <div class="stars">★★★★★</div>
          </div>
        </div>
        <p class="testimonial-text">"Am creat un curs complet despre Amazon FBA în doar 3 ore cu AI Builder. Calitatea este impresionantă și cursanții mei sunt încântați!"</p>
        <div class="testimonial-results">
          <span class="result-label">Rezultat:</span> 15 vânzări în prima săptămână
        </div>
      </div>
      
      <div class="testimonial-card">
        <div class="testimonial-header">
          <img src="angela-profile.jpg" alt="Angela, Antreprenor" class="profile-image-small">
          <div class="testimonial-meta">
            <h4>Angela, Antreprenor</h4>
            <div class="stars">★★★★★</div>
          </div>
        </div>
        <p class="testimonial-text">"AI Builder mi-a economisit cel puțin 40 de ore de muncă. Am creat un curs de marketing digital care arată ca și cum aș fi lucrat cu o echipă de profesioniști."</p>
        <div class="testimonial-results">
          <span class="result-label">Rezultat:</span> 3,200€ venituri în 30 de zile
        </div>
      </div>
      
      <div class="testimonial-card">
        <div class="testimonial-header">
          <img src="ovidiu-profile.jpg" alt="Ovidiu, Health Solutions" class="profile-image-small">
          <div class="testimonial-meta">
            <h4>Ovidiu, Health Solutions</h4>
            <div class="stars">★★★★★</div>
          </div>
        </div>
        <p class="testimonial-text">"Sunt uimit de ce poate face Builder AI. Recomand insistent! Am creat un program de nutriție complet în timp record și clienții mei sunt impresionați de calitate."</p>
        <div class="testimonial-results">
          <span class="result-label">Rezultat:</span> 28 de înscrieri în primul webinar
        </div>
      </div>
    </div>
    
    <div class="testimonials-cta">
      <h3>Alătură-te experților de succes</h3>
      <a href="#pricing" class="cta-button primary">Începe să creezi acum</a>
    </div>
  </div>
</section>
```

### Stilizare CSS pentru secțiunea de testimoniale

```css
.testimonials {
  padding: 80px 0;
  background-color: #f8f9fa;
}

.featured-case-study {
  background-color: white;
  border-radius: 12px;
  padding: 40px;
  margin: 50px 0;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.case-study-header {
  display: flex;
  align-items: center;
  margin-bottom: 30px;
}

.profile-image {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: 20px;
  border: 3px solid #FF6B00;
}

.case-study-meta h3 {
  font-size: 1.6rem;
  margin-bottom: 10px;
  color: #333;
}

.results-highlight {
  background-color: #E8F5E9;
  color: #2E7D32;
  padding: 5px 15px;
  border-radius: 20px;
  display: inline-block;
  font-weight: 600;
}

.result-number {
  font-weight: 700;
}

.case-study-story {
  color: #333;
  line-height: 1.7;
}

.case-study-story p {
  margin-bottom: 20px;
}

.challenge {
  border-left: 3px solid #F44336;
  padding-left: 15px;
}

.solution {
  border-left: 3px solid #2196F3;
  padding-left: 15px;
}

.results {
  border-left: 3px solid #4CAF50;
  padding-left: 15px;
  font-weight: 600;
}

.course-preview {
  margin-top: 30px;
  text-align: center;
}

.course-image {
  max-width: 100%;
  border-radius: 8px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.testimonials-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
  margin: 50px 0;
}

.testimonial-card {
  background-color: white;
  border-radius: 12px;
  padding: 30px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
}

.testimonial-header {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}

.profile-image-small {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: 15px;
}

.testimonial-meta h4 {
  font-size: 1.2rem;
  margin-bottom: 5px;
  color: #333;
}

.stars {
  color: #FFD700;
  letter-spacing: 2px;
}

.testimonial-text {
  color: #555;
  line-height: 1.6;
  font-style: italic;
  margin-bottom: 20px;
}

.testimonial-results {
  background-color: #F5F5F5;
  padding: 10px 15px;
  border-radius: 8px;
  font-size: 0.9rem;
}

.result-label {
  font-weight: 600;
  color: #333;
}

.testimonials-cta {
  text-align: center;
  margin-top: 50px;
}

.testimonials-cta h3 {
  font-size: 1.6rem;
  margin-bottom: 20px;
  color: #333;
}
```

## 5. Secțiunea de prețuri și pachete

```html
<section id="pricing" class="pricing">
  <div class="container">
    <div class="section-header">
      <h2>Investește în succesul tău</h2>
      <p class="section-subtitle">Alege pachetul care ți se potrivește și începe să creezi cursuri premium astăzi</p>
    </div>
    
    <div class="pricing-comparison">
      <div class="pricing-column traditional">
        <div class="pricing-header">
          <h3>Metoda tradițională</h3>
          <div class="price">
            <span class="currency">€</span>
            <span class="amount">2,000+</span>
          </div>
          <p class="price-description">Cost estimat pentru crearea unui curs</p>
        </div>
        
        <div class="pricing-features">
          <div class="feature-item negative">
            <span class="feature-icon">✕</span>
            <p>Săptămâni sau luni de muncă</p>
          </div>
          <div class="feature-item negative">
            <span class="feature-icon">✕</span>
            <p>Necesită cunoștințe tehnice</p>
          </div>
          <div class="feature-item negative">
            <span class="feature-icon">✕</span>
            <p>Costuri pentru designeri și editori</p>
          </div>
          <div class="feature-item negative">
            <span class="feature-icon">✕</span>
            <p>Rezultate inconsistente</p>
          </div>
          <div class="feature-item negative">
            <span class="feature-icon">✕</span>
            <p>Fără suport sau actualizări</p>
          </div>
        </div>
      </div>
      
      <div class="pricing-column ai-builder featured">
        <div class="pricing-badge">Ofertă limitată</div>
        <div class="pricing-header">
          <h3>AI Builder</h3>
          <div class="price">
            <span class="original-price">€970</span>
            <span class="currency">€</span>
            <span class="amount">197</span>
          </div>
          <p class="price-description">Acces pe viață + Actualizări gratuite</p>
        </div>
        
        <div class="pricing-features">
          <div class="feature-item positive">
            <span class="feature-icon">✓</span>
            <p>Creează cursuri complete în ore, nu săptămâni</p>
          </div>
          <div class="feature-item positive">
            <span class="feature-icon">✓</span>
            <p>Interfață intuitivă, fără cunoștințe tehnice</p>
          </div>
          <div class="feature-item positive">
            <span class="feature-icon">✓</span>
            <p>Design profesional și slide-uri premium</p>
          </div>
          <div class="feature-item positive">
            <span class="feature-icon">✓</span>
            <p>Exportare în multiple formate</p>
          </div>
          <div class="feature-item positive">
            <span class="feature-icon">✓</span>
            <p>Suport tehnic dedicat</p>
          </div>
        </div>
        
        <div class="bonus-section">
          <h4>BONUS-URI INCLUSE</h4>
          <div class="bonus-item">
            <span class="bonus-icon">🎁</span>
            <div class="bonus-details">
              <h5>Ghid de marketing pentru cursuri</h5>
              <p>Valoare: €97</p>
            </div>
          </div>
          <div class="bonus-item">
            <span class="bonus-icon">🎁</span>
            <div class="bonus-details">
              <h5>2 zile VIP Marketing</h5>
              <p>Valoare: €197</p>
            </div>
          </div>
          <div class="bonus-item">
            <span class="bonus-icon">🎁</span>
            <div class="bonus-details">
              <h5>Acces la comunitatea privată</h5>
              <p>Valoare: €147</p>
            </div>
          </div>
        </div>
        
        <div class="pricing-cta">
          <a href="#checkout" class="cta-button primary full-width">Obține acces acum</a>
          <div class="countdown-timer">
            <p>Oferta expiră în:</p>
            <div class="timer">
              <span class="days">02</span>:<span class="hours">11</span>:<span class="minutes">45</span>:<span class="seconds">30</span>
            </div>
          </div>
        </div>
        
        <div class="guarantee">
          <img src="guarantee-badge.png" alt="Garanție 30 zile" class="guarantee-badge">
          <p>Garanție de returnare a banilor 30 de zile, fără întrebări</p>
        </div>
      </div>
    </div>
  </div>
</section>
```

### Stilizare CSS pentru secțiunea de prețuri

```css
.pricing {
  padding: 80px 0;
  background-color: white;
}

.pricing-comparison {
  display: flex;
  justify-content: center;
  gap: 30px;
  margin-top: 50px;
  flex-wrap: wrap;
}

.pricing-column {
  flex: 1;
  min-width: 300px;
  max-width: 450px;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
}

.pricing-column.traditional {
  background-color: #f8f9fa;
  border: 1px solid #e9ecef;
}

.pricing-column.ai-builder {
  background-color: white;
  border: 1px solid #e9ecef;
  position: relative;
}

.pricing-column.featured {
  transform: scale(1.05);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  z-index: 2;
  border: 2px solid #FF6B00;
}

.pricing-badge {
  position: absolute;
  top: 0;
  right: 0;
  background-color: #FF6B00;
  color: white;
  padding: 5px 15px;
  font-size: 0.9rem;
  font-weight: 600;
  border-bottom-left-radius: 8px;
}

.pricing-header {
  padding: 30px;
  text-align: center;
  border-bottom: 1px solid #e9ecef;
}

.pricing-header h3 {
  font-size: 1.6rem;
  margin-bottom: 20px;
  color: #333;
}

.price {
  margin-bottom: 15px;
}

.original-price {
  text-decoration: line-through;
  color: #999;
  font-size: 1.2rem;
  margin-right: 10px;
}

.currency {
  font-size: 1.5rem;
  vertical-align: top;
  position: relative;
  top: 0.5rem;
}

.amount {
  font-size: 3rem;
  font-weight: 700;
  color: #333;
}

.price-description {
  color: #666;
  font-size: 0.9rem;
}

.pricing-features {
  padding: 30px;
}

.feature-item {
  display: flex;
  align-items: flex-start;
  margin-bottom: 15px;
}

.feature-icon {
  margin-right: 10px;
  flex-shrink: 0;
}

.feature-item.positive .feature-icon {
  color: #4CAF50;
  font-weight: bold;
}

.feature-item.negative .feature-icon {
  color: #F44336;
}

.feature-item p {
  margin: 0;
  color: #333;
  line-height: 1.5;
}

.bonus-section {
  padding: 20px 30px;
  background-color: #FFF8E1;
  border-top: 1px solid #FFE082;
  border-bottom: 1px solid #FFE082;
}

.bonus-section h4 {
  text-align: center;
  font-size: 1.1rem;
  margin-bottom: 15px;
  color: #FF6B00;
}

.bonus-item {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
}

.bonus-icon {
  font-size: 1.2rem;
  margin-right: 10px;
}

.bonus-details h5 {
  font-size: 1rem;
  margin: 0 0 5px 0;
  color: #333;
}

.bonus-details p {
  margin: 0;
  color: #666;
  font-size: 0.9rem;
}

.pricing-cta {
  padding: 30px;
  text-align: center;
}

.cta-button.full-width {
  width: 100%;
  padding: 15px;
  font-size: 1.1rem;
}

.countdown-timer {
  margin-top: 20px;
  text-align: center;
}

.countdown-timer p {
  margin-bottom: 5px;
  color: #666;
  font-size: 0.9rem;
}

.timer {
  font-size: 1.2rem;
  font-weight: 700;
  color: #FF6B00;
}

.guarantee {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 30px 30px;
  text-align: center;
}

.guarantee-badge {
  width: 60px;
  margin-right: 15px;
}

.guarantee p {
  font-size: 0.9rem;
  color: #666;
  margin: 0;
}
```

## 6. Formular de checkout optimizat

```html
<section id="checkout" class="checkout">
  <div class="container">
    <div class="checkout-container">
      <div class="checkout-header">
        <h2>Finalizează comanda</h2>
        <p>Completează detaliile pentru a obține acces imediat la AI Builder</p>
      </div>
      
      <div class="checkout-content">
        <div class="checkout-form">
          <form id="order-form">
            <div class="form-step active" id="step-1">
              <h3>Pasul 1: Informații de contact</h3>
              
              <div class="form-group">
                <label for="email">Adresa de email</label>
                <input type="email" id="email" placeholder="exemplu@gmail.com" required>
                <p class="form-hint">Vei primi accesul la AI Builder pe această adresă</p>
              </div>
              
              <div class="form-actions">
                <button type="button" class="btn-next">Continuă la plată</button>
              </div>
            </div>
            
            <div class="form-step" id="step-2">
              <h3>Pasul 2: Detalii personale</h3>
              
              <div class="form-row">
                <div class="form-group">
                  <label for="first-name">Prenume</label>
                  <input type="text" id="first-name" required>
                </div>
                
                <div class="form-group">
                  <label for="last-name">Nume</label>
                  <input type="text" id="last-name" required>
                </div>
              </div>
              
              <div class="form-group">
                <label for="company">Nume companie (opțional)</label>
                <input type="text" id="company">
              </div>
              
              <div class="form-group">
                <label for="phone">Număr de telefon</label>
                <input type="tel" id="phone" required>
              </div>
              
              <div class="form-actions">
                <button type="button" class="btn-prev">Înapoi</button>
                <button type="button" class="btn-next">Continuă la plată</button>
              </div>
            </div>
            
            <div class="form-step" id="step-3">
              <h3>Pasul 3: Informații de plată</h3>
              
              <div class="payment-methods">
                <div class="payment-method active">
                  <input type="radio" id="card" name="payment-method" checked>
                  <label for="card">Card</label>
                </div>
                
                <div class="payment-method">
                  <input type="radio" id="paypal" name="payment-method">
                  <label for="paypal">PayPal</label>
                </div>
                
                <div class="payment-method">
                  <input type="radio" id="bank-transfer" name="payment-method">
                  <label for="bank-transfer">Transfer bancar</label>
                </div>
              </div>
              
              <div class="card-details">
                <div class="form-group">
                  <label for="card-number">Număr card</label>
                  <div class="card-input-container">
                    <input type="text" id="card-number" placeholder="1234 5678 9012 3456" required>
                    <div class="card-icons">
                      <img src="visa.png" alt="Visa">
                      <img src="mastercard.png" alt="Mastercard">
                    </div>
                  </div>
                </div>
                
                <div class="form-row">
                  <div class="form-group">
                    <label for="expiry">Data expirării</label>
                    <input type="text" id="expiry" placeholder="MM/YY" required>
                  </div>
                  
                  <div class="form-group">
                    <label for="cvv">CVV</label>
                    <input type="text" id="cvv" placeholder="123" required>
                  </div>
                </div>
              </div>
              
              <div class="form-actions">
                <button type="button" class="btn-prev">Înapoi</button>
                <button type="submit" class="btn-submit">Finalizează comanda</button>
              </div>
            </div>
          </form>
        </div>
        
        <div class="order-summary">
          <h3>Sumar comandă</h3>
          
          <div class="product-details">
            <img src="ai-builder-icon.png" alt="AI Builder" class="product-image">
            <div class="product-info">
              <h4>AI Builder Premium</h4>
              <p>Acces pe viață + Actualizări gratuite</p>
            </div>
          </div>
          
          <div class="price-breakdown">
            <div class="price-row">
              <span>Preț standard</span>
              <span>€970</span>
            </div>
            <div class="price-row discount">
              <span>Reducere (80%)</span>
              <span>-€773</span>
            </div>
            <div class="price-row total">
              <span>Total de plată</span>
              <span>€197</span>
            </div>
          </div>
          
          <div class="bonuses-included">
            <h4>BONUS-URI INCLUSE</h4>
            <ul class="bonus-list">
              <li>Ghid de marketing pentru cursuri</li>
              <li>2 zile VIP Marketing</li>
              <li>Acces la comunitatea privată</li>
            </ul>
          </div>
          
          <div class="security-badges">
            <div class="security-badge">
              <img src="secure-payment.png" alt="Plată securizată">
              <span>Plată 100% sigură și securizată</span>
            </div>
            <div class="security-badge">
              <img src="money-back.png" alt="Garanție bani înapoi">
              <span>Garanție 30 zile bani înapoi</span>
            </div>
          </div>
          
          <div class="testimonial-mini">
            <p>"Am recuperat investiția de 12 ori în doar câteva zile!"</p>
            <div class="testimonial-author">
              <img src="andrei-small.jpg" alt="Andrei" class="author-image">
              <span>Andrei, Coach Spiritual</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
```

### Stilizare CSS pentru formularul de checkout

```css
.checkout {
  padding: 80px 0;
  background-color: #f8f9fa;
}

.checkout-container {
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.checkout-header {
  background-color: #333;
  color: white;
  padding: 30px;
  text-align: center;
}

.checkout-header h2 {
  font-size: 2rem;
  margin-bottom: 10px;
}

.checkout-header p {
  color: #ccc;
}

.checkout-content {
  display: flex;
  flex-wrap: wrap;
}

.checkout-form {
  flex: 2;
  min-width: 300px;
  padding: 30px;
  border-right: 1px solid #e9ecef;
}

.order-summary {
  flex: 1;
  min-width: 300px;
  padding: 30px;
  background-color: #f8f9fa;
}

.form-step {
  display: none;
}

.form-step.active {
  display: block;
}

.form-step h3 {
  font-size: 1.4rem;
  margin-bottom: 20px;
  color: #333;
  padding-bottom: 10px;
  border-bottom: 1px solid #e9ecef;
}

.form-group {
  margin-bottom: 20px;
}

.form-row {
  display: flex;
  gap: 20px;
}

.form-row .form-group {
  flex: 1;
}

label {
  display: block;
  margin-bottom: 8px;
  font-weight: 600;
  color: #333;
}

input[type="text"],
input[type="email"],
input[type="tel"] {
  width: 100%;
  padding: 12px 15px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 1rem;
}

input[type="text"]:focus,
input[type="email"]:focus,
input[type="tel"]:focus {
  border-color: #FF6B00;
  outline: none;
  box-shadow: 0 0 0 3px rgba(255, 107, 0, 0.1);
}

.form-hint {
  font-size: 0.85rem;
  color: #666;
  margin-top: 5px;
}

.form-actions {
  display: flex;
  justify-content: space-between;
  margin-top: 30px;
}

.btn-prev,
.btn-next,
.btn-submit {
  padding: 12px 25px;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-prev {
  background-color: #f8f9fa;
  border: 1px solid #ddd;
  color: #333;
}

.btn-prev:hover {
  background-color: #e9ecef;
}

.btn-next,
.btn-submit {
  background-color: #FF6B00;
  border: none;
  color: white;
}

.btn-next:hover,
.btn-submit:hover {
  background-color: #FF8C00;
}

.payment-methods {
  display: flex;
  margin-bottom: 20px;
  border: 1px solid #ddd;
  border-radius: 6px;
  overflow: hidden;
}

.payment-method {
  flex: 1;
  text-align: center;
  padding: 15px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.payment-method.active {
  background-color: #f8f9fa;
  font-weight: 600;
}

.payment-method input {
  margin-right: 5px;
}

.card-input-container {
  position: relative;
}

.card-icons {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  gap: 5px;
}

.card-icons img {
  height: 20px;
}

.order-summary h3 {
  font-size: 1.4rem;
  margin-bottom: 20px;
  color: #333;
}

.product-details {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid #e9ecef;
}

.product-image {
  width: 60px;
  height: 60px;
  border-radius: 8px;
  margin-right: 15px;
}

.product-info h4 {
  font-size: 1.1rem;
  margin-bottom: 5px;
  color: #333;
}

.product-info p {
  color: #666;
  font-size: 0.9rem;
}

.price-breakdown {
  margin-bottom: 20px;
}

.price-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  font-size: 0.95rem;
  color: #666;
}

.price-row.discount {
  color: #F44336;
}

.price-row.total {
  font-size: 1.2rem;
  font-weight: 700;
  color: #333;
  padding-top: 10px;
  border-top: 1px solid #e9ecef;
}

.bonuses-included {
  background-color: #FFF8E1;
  padding: 15px;
  border-radius: 8px;
  margin-bottom: 20px;
}

.bonuses-included h4 {
  font-size: 1rem;
  margin-bottom: 10px;
  color: #FF6B00;
}

.bonus-list {
  padding-left: 20px;
  margin: 0;
}

.bonus-list li {
  margin-bottom: 5px;
  font-size: 0.9rem;
}

.security-badges {
  margin-bottom: 20px;
}

.security-badge {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.security-badge img {
  width: 24px;
  margin-right: 10px;
}

.security-badge span {
  font-size: 0.85rem;
  color: #666;
}

.testimonial-mini {
  background-color: #E8F5E9;
  padding: 15px;
  border-radius: 8px;
  font-style: italic;
}

.testimonial-mini p {
  margin-bottom: 10px;
  font-size: 0.95rem;
  color: #333;
}

.testimonial-author {
  display: flex;
  align-items: center;
}

.author-image {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  margin-right: 10px;
}

.testimonial-author span {
  font-size: 0.85rem;
  font-weight: 600;
  color: #333;
}
```

Aceste elemente de design reprezintă componentele principale pentru o pagină de vânzare cu conversie ridicată pentru AiBuilder.biz. Ele sunt create pentru a rezolva problemele identificate în analiza inițială și pentru a implementa cele mai bune practici de optimizare a conversiei pentru pagini de vânzare de cursuri online.

Elementele includ:
1. Un header optimizat "above the fold" cu propunere de valoare clară și CTA vizibil
2. O secțiune "Problema și Soluția" care adresează direct frustrările publicului țintă
3. O secțiune "Cum funcționează" cu pași simpli și vizuali
4. Testimoniale și studii de caz puternice cu rezultate concrete
5. O secțiune de prețuri care evidențiază valoarea și include elemente de urgență autentice
6. Un formular de checkout optimizat pentru conversie

Aceste elemente pot fi implementate treptat, conform planului de implementare din recomandările anterioare.
